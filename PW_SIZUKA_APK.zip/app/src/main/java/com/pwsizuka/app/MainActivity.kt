package com.pwsizuka.app

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var overlay: LinearLayout
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val host = "appassets.androidplatform.net"
    private val handler = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { hideOverlay() }

    private fun showOverlay() {
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideRun)
        handler.postDelayed(hideRun, 30000)
    }

    private fun hideOverlay() {
        handler.removeCallbacks(hideRun)
        overlay.visibility = View.GONE
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#080817")
        window.navigationBarColor = Color.parseColor("#080817")

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#080817"))

        val d = resources.displayMetrics.density
        overlay = LinearLayout(this)
        overlay.orientation = LinearLayout.VERTICAL
        overlay.gravity = Gravity.CENTER
        overlay.setBackgroundColor(Color.parseColor("#F2080817"))
        overlay.visibility = View.GONE
        overlay.isClickable = true
        val bar = ProgressBar(this)
        bar.indeterminateTintList = ColorStateList.valueOf(Color.parseColor("#ff4d6d"))
        overlay.addView(bar, LinearLayout.LayoutParams((52 * d).toInt(), (52 * d).toInt()))
        val label = TextView(this)
        label.text = "PLEASE WAIT FOR A MOMENT"
        label.setTextColor(Color.WHITE)
        label.textSize = 15f
        label.typeface = Typeface.DEFAULT_BOLD
        label.letterSpacing = 0.15f
        label.gravity = Gravity.CENTER
        label.setPadding((20 * d).toInt(), (24 * d).toInt(), (20 * d).toInt(), 0)
        overlay.addView(label)

        val frame = FrameLayout(this)
        frame.addView(web, FrameLayout.LayoutParams(-1, -1))
        frame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.allowFileAccess = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                return request?.let { loader.shouldInterceptRequest(it.url) }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null) return false
                val u = request.url
                if (u.host == host) return false
                val scheme = u.scheme ?: ""
                val isWeb = scheme == "http" || scheme == "https"
                val h = (u.host ?: "").lowercase()
                val needsOtherApp = h == "t.me" || h == "telegram.me" || h.endsWith("whatsapp.com") || h == "wa.me"
                if (!isWeb || needsOtherApp) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                    return true
                }
                if (request.isForMainFrame) showOverlay()
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null && !url.contains(host)) showOverlay()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                hideOverlay()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) hideOverlay()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress >= 90) hideOverlay()
            }

            override fun onShowCustomView(v: View?, cb: CustomViewCallback?) {
                if (customView != null) { cb?.onCustomViewHidden(); return }
                customView = v
                customCb = cb
                (window.decorView as ViewGroup).addView(
                    v, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            }

            override fun onHideCustomView() {
                customView?.let { (window.decorView as ViewGroup).removeView(it) }
                customView = null
                customCb?.onCustomViewHidden()
                customCb = null
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            }
        }

        web.setDownloadListener { url, _, _, _, _ ->
            try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } catch (e: Exception) {}
        }

        if (b == null) web.loadUrl("https://$host/assets/index.html") else web.restoreState(b)
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        web.saveState(out)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            overlay.visibility == View.VISIBLE -> { web.stopLoading(); hideOverlay() }
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
}
